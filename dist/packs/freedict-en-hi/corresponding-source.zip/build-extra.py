#!/usr/bin/env python3
"""Build the two additional language packs from pinned FreeDict release archives (offline)."""
from collections import defaultdict
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
from xml.etree import ElementTree as ET
import argparse, json, re, tarfile
import build as base

SRC={
 'hi':('eng-hin','1.6',25642,'3e2d30fa5b7bdb67f076362113491f87c119ca6b1542f455aec69411dafe3003e80ab1775a9df188ecaae3373a8ec61a61e93c05eace31844493c467b6f22ec4'),
 'es':('eng-spa','2025.11.23',64258,'622e8fec6c4178cb4c21e4577701c5325670f825331b07a185b4c6b810603c337e80429738a97581f68f668667910e7ad36f27332eaee2828f1f906537852fe3')}
N=base.N
LANG='{http://www.w3.org/XML/1998/namespace}lang'
HIPOS={'N':'noun','Adj':'adjective','V':'verb','VT':'verb','VI':'verb','VTI':'verb','PhrV':'phrasal verb','PhrVT':'phrasal verb','PhrVI':'phrasal verb','Adv':'adverb','IDM':'idiom','Prep':'preposition','Pron':'pronoun','Conj':'conjunction','Det':'determiner','Interj':'interjection','Pref':'prefix','Suffix':'suffix'}
DATE='2026-11-22'
CREDITS='https://freedict.org/downloads/'
def clean(s): return base.plain(''.join(s.itertext())).strip() if s is not None else ''
def unique(seq): return list(dict.fromkeys(x for x in seq if x))
def write_source(out,path,notice,lic):
    readme="""Hindi dictionary source for the Folio adaptation
The complete original release, license and complete conversion scripts are included.
Requires only Python 3 standard library. To reproduce the Hindi pack:
  python3 build-extra.py --hi eng-hin.src.tar.xz --out rebuilt-packs
To edit, change the TEI in your own working copy and update the pinned checksum deliberately.
For changes to the data, keep the original credits and publish your changes under GPL-2.0-or-later.
"""
    with ZipFile(out/'corresponding-source.zip','w') as z:
        for filename,content in [('README.txt',readme.encode()),('NOTICE.txt',notice.encode()),('LICENSE.txt',lic),
            ('eng-hin.src.tar.xz',path.read_bytes()),('build.py',Path(base.__file__).read_bytes()),('build-extra.py',Path(__file__).read_bytes())]:
            info=ZipInfo(filename,(2026,11,22,0,0,0));info.compress_type=ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,content)
    import html
    (out/'credits.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>English → Hindi · Credits and source</title><main style="max-width:65ch;margin:6vh auto;padding:1em;font:16px/1.6 system-ui"><h1>English → Hindi</h1><p><a href="corresponding-source.zip" download>Download the complete editable dictionary source and conversion scripts (ZIP)</a> · <a href="LICENSE.txt">Full GPL license</a></p><pre style="white-space:pre-wrap;overflow-wrap:anywhere">'+html.escape(notice)+'</pre></main></html>')
def build(path,target,out):
    pair,version,count,digest=SRC[target];base.check(path,'sha512',digest)
    official=f'https://download.freedict.org/dictionaries/{pair}/{version}/freedict-{pair}-{version}.src.tar.xz'
    ishi=target=='hi';data=defaultdict(list); articles=0
    with tarfile.open(path,'r:xz') as t:
        lic=t.extractfile(pair+'/COPYING').read()
        for _,e in ET.iterparse(t.extractfile(pair+'/'+pair+'.tei')):
            if e.tag==N+'teiHeader':
                title=clean(e.find('.//'+N+'title')); ed=clean(e.find('.//'+N+'edition'))
                assert title.startswith('English-') and ed==version
                assert ('Hindi' if ishi else 'español') in title
                assert ('GNU General Public License ver. 2.0 and any later version' if ishi else 'Creative Commons Attribution-ShareAlike 3.0 Unported') in clean(e)
            if e.tag!=N+'entry': continue
            articles+=1
            h=clean(e.find(N+'form/'+N+'orth'));k=base.normalized(h,'en');assert k
            p=clean(e.find(N+'gramGrp/'+N+'pos'));p=HIPOS.get(p,p) if ishi else base.POS.get(p,p)
            ipa=' · '.join(unique(clean(x) for x in e.findall(N+'form/'+N+'pron')))
            for s in e.findall(N+'sense'):
                tr=[]
                for c in s.findall(N+'cit[@type="trans"]'):
                    if not ishi: assert c.get(LANG)==target
                    elif c.get(LANG) not in (None,'hi'): continue
                    for q in c.findall(N+'quote'):
                        val=clean(q)
                        if ishi:
                            if not re.search('[ऄ-हक़-ॡ]',val) or re.search('[A-Za-z?]',val): continue
                            val=' '.join(val.replace('~',' ').replace('_',' ').replace('{',' (').replace('}',')').split())
                        # No placeholder/wikimarkup/English definition becomes a translated sense.
                        if not val or not any(ch.isalpha() for ch in val) or re.search(r'\[\[|\]\]|\{\{|\}\}',val): continue
                        tr.append(val)
                if not tr: continue
                defs=unique(clean(x) for x in s.iter(N+'def')) if not ishi else []
                ex=clean(s.find(N+'cit[@type="example"]/'+N+'quote')) if ishi else ''
                for gloss in defs or ['']:
                    rec=[h,'; '.join(unique(tr)),gloss,p,ex,ipa]
                    if rec not in data[k]:data[k].append(rec)
            e.clear()
    assert articles==count
    if not ishi:
        for rows in data.values():rows.sort(key=lambda s:bool(re.match(r'^\([^)]*\b(?:archaic|obsolete)\b',s[2],re.I)))
    meta=dict(id='freedict-en-'+target,title='Английский → '+('хинди' if ishi else 'испанский'),
        description=('Значения на хинди и примеры. Издание 1.6: по оценке издателя, качество статей неоднородно.' if ishi else 'Испанские переводы по значениям слова из FreeDict / WikDict.'),
        language='en',target=target,source='FreeDict / IIIT Hyderabad' if ishi else 'FreeDict / WikDict',
        license='GPL-2.0-or-later' if ishi else 'CC BY-SA 3.0',version=version,sourceEntries=count,sourceUrl=CREDITS,
        licenseUrl='https://www.gnu.org/licenses/old-licenses/gpl-2.0.html' if ishi else 'https://creativecommons.org/licenses/by-sa/3.0/')
    credit=('Copyright (C) 1999–2017 by the various authors listed in the original release. Anusaaraka English-Hindi Dictionary v2.0: Language Technologies Research Centre, IIIT Hyderabad, India, and its volunteer contributors; funded by Satyam Computers. FreeDict maintainer/converter: Michael Bunk. Additional contributors include Piotr Bański, Denis Arnaud and Sebastian Humenda. The complete upstream copyright, warranty and contributor information is preserved with the original in corresponding-source.zip. This data and its JSON adaptation are provided under GPL v2 or, at your option, any later version. No warranty. Download the editable original and both build scripts in corresponding-source.zip beside this notice. Quality is not uniform according to its publisher. Omitted missing, question-mark and mixed Latin/Devanagari translation tokens (this can omit legitimate technical vocabulary); used spaces for upstream tilde/underscore separators and parentheses for sense notes, retained first example per sense and grouped translations by sense.' if ishi else
        'Wiktionary contributors → DBnary → WikDict (Karl Bartel) → FreeDict. https://www.wiktionary.org/ · https://kaiko.getalp.org/about-dbnary/ · https://www.wikdict.com/ · https://freedict.org/. Source and the Folio adaptation distributed under Creative Commons Attribution-ShareAlike 3.0 Unported. Converted TEI English headwords and Spanish-marked translations, POS, pronunciations and associated English glosses into a local index. Dropped unusable/markup-only translations, kept valid senses distinct, normalized keys, deduplicated readings and moved expressly obsolete/archaic readings after current ones.')
    notice=f"FreeDict {pair} {version}. Modified by Folio on {DATE}.\n\n{credit}\n\nOriginal source: {official}\nSHA-512: {digest}\nPublisher checksums: https://freedict.org/freedict-database.json\nLicense: {meta['licenseUrl']} (verbatim LICENSE.txt accompanies this pack).\n\n{count:,} source articles; {len(data):,} distinct normalized lookup headwords. Data-only dictionary pack. Not a sentence translator. No endorsement implied.\n"
    meta=base.savepack(out,meta,data,notice,lic)
    if ishi:
        write_source(out/meta['id'],path,notice,lic)
        meta['noticeUrl']='./packs/'+meta['id']+'/credits.html'
    return meta
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for target in SRC:p.add_argument('--'+target,type=Path)
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[2]/'dist/packs');a=p.parse_args()
    if not(a.hi or a.es):p.error('pass --hi and/or --es')
    cf=a.out/'catalog.js'; src=cf.read_text() if cf.exists() else ''
    catalog=json.loads(src.split('export const recommendedPacks = ',1)[1].strip().removesuffix(';')) if src else []
    for target in SRC:
        if path:=getattr(a,target):
            item=build(path,target,a.out);catalog=[p for p in catalog if p['id']!=item['id']]+[item]
    cf.write_text('// Generated by tools/dictionaries/build.py and build-extra.py; metadata only.\nexport const recommendedPacks = '+json.dumps(catalog,ensure_ascii=False,indent=2)+';\n')

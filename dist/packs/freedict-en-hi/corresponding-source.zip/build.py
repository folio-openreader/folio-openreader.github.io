#!/usr/bin/env python3
"""Deterministic offline conversion. Inputs are explicitly pinned public dictionary archives.
Usage: python3 tools/dictionaries/build.py --en-ru FILE --ru-en FILE --wordnet FILE [--out DIST/PACKS]
No network or third-party modules. No downloaded code is executed.
"""
import argparse
import collections
import hashlib
import html
import json
import re
import tarfile
import unicodedata
from pathlib import Path
from xml.etree import ElementTree as ET

VERSION = '2025.11.23'
FD = {
    'eng-rus': ('en', 'ru', 62181, 'fdee5ebdbe59c2a4293b875def3befdfddd990f95ecd10eb289eff22d815ed6d31267ca4695af66811ef368dd72b16342210475e044c995831e7931ce0e4bcfe'),
    'rus-eng': ('ru', 'en', 42600, '9adf7a5eda27ccfa3e496b86b2fd575fc0e4af7ac5626a219d44e4ebfd56280deaf67cefd995ab04e9d7ef415e88f8cf0f9cae3252da6221376fd6d0c39012ba'),
}
WN_HASH = '3f7d8be8ef6ecc7167d39b10d66954ec734280b5bdcd57f7d9eafe429d11c22a'
SIZE = 512_000
N = '{http://www.tei-c.org/ns/1.0}'
POS = {'n':'noun','v':'verb','adj':'adjective','adv':'adverb','pn':'proper noun',
       'phraseologicalUnit':'phrase','participleAdjective':'participial adjective'}

def jbytes(v):
    return json.dumps(v, ensure_ascii=False, separators=(',', ':')).encode()

def sha(b):
    return hashlib.sha256(b).hexdigest()

def normalized(s, lang):
    s = ' '.join(unicodedata.normalize('NFKC', s).lower().replace('‘', "'").replace('’', "'").split())
    return s.replace('\u0301', '') if lang == 'ru' else s

def plain(s):
    # Unwrap wikilinks to their display label, never insert the input as HTML.
    s=html.unescape(s)
    s=re.sub(r'</?(?:i|b|u|sup|sub|span)(?:\s[^>]*?)?>', '', s, flags=re.I)
    s=re.sub(r'\[\[([^\[\]]+)\]\]', lambda m:m[1].split('|')[-1], s)
    return ' '.join(s.split())

def check(path, algorithm, expected):
    if hashlib.new(algorithm, path.read_bytes()).hexdigest() != expected:
        raise ValueError(f'{path} does not match pinned {algorithm} checksum')

def savepack(out, meta, data, notice, license_data):
    heads=sum(any(normalized(s[0],meta['language'])==k for s in senses) for k,senses in data.items())
    pack = out / meta['id']
    pack.mkdir(parents=True,exist_ok=True)
    (pack/'LICENSE.txt').write_bytes(license_data)
    (pack/'NOTICE.txt').write_text(notice)
    group, size, shards = [], 2, []
    def flush():
        if not group: return
        b=b'['+b',\n'.join(group)+b']\n'
        # Immutable names permit in-flight upgrade without mixed versions.
        f='part-%03d-%s.json' % (len(shards)+1,sha(b)[:12])
        (pack/f).write_bytes(b)
        shards.append({'file':f,'bytes':len(b),'sha256':sha(b),'keys':len(group)})
    for k in sorted(data, key=lambda x:x.encode('utf-16-be')):
        senses=data[k]
        assert k and senses
        for s in senses:
            while s and s[-1]=='': s.pop()
        line=jbytes([k,senses])
        if group and size+len(line)+2>SIZE:
            flush()
            group, size=[], 2
        group.append(line);size+=len(line)+2
    flush()
    manifest={'format':1,'id':meta['id'],'version':meta['version'],'count':heads,'keys':len(data),'shards':shards,'notice':notice,'licenseUrl':meta['licenseUrl']}
    mb=jbytes(manifest)+b'\n'
    (pack/'manifest.json').write_bytes(mb)
    meta.update(count=heads,bytes=sum(s['bytes'] for s in shards),manifest='./packs/'+meta['id']+'/manifest.json',manifestSha256=sha(mb),noticeUrl='./packs/'+meta['id']+'/NOTICE.txt')
    stats={'senses':sum(map(len,data.values())), 'maxSenses':max(map(len,data.values())), 'maxKey':max(map(len,data)), 'maxFields':[max((len(s[i]) for v in data.values() for s in v if len(s)>i),default=0) for i in range(6)]}
    print(meta['id'],len(data),stats,len(shards),'shards,',meta['bytes'],'bytes',flush=True)
    return meta

def freedict(path, pair, out):
    lang, target, n, expected=FD[pair]
    check(path,'sha512',expected)
    data=collections.defaultdict(list)
    source_url=f'https://download.freedict.org/dictionaries/{pair}/{VERSION}/freedict-{pair}-{VERSION}.src.tar.xz'
    with tarfile.open(path, 'r:xz') as tar:
        lic=tar.extractfile(pair+'/COPYING').read()
        count=0; unavailable=0
        for _,el in ET.iterparse(tar.extractfile(pair+'/'+pair+'.tei')):
            if el.tag!=N+'entry': continue
            count+=1
            head=el.findtext(N+'form/'+N+'orth')
            k=normalized(head,lang)
            pos=el.findtext(N+'gramGrp/'+N+'pos') or ''
            pos=POS.get(pos,pos)
            # Display variants from the lexicographic record (not machine-generated audio).
            ipas=list(dict.fromkeys(plain(x.text) for x in el.findall(N+'form/'+N+'pron') if x.text))
            pron=' · '.join(ipas)
            for sense in el.findall(N+'sense'):
                quotes=sense.findall(N+'cit[@type="trans"]/'+N+'quote')
                # Literal duplicate spellings (inc. duplicated stress/nonstress variants) need only appear once.
                tr=[]; seen=set()
                for q in quotes:
                    v=plain(''.join(q.itertext()))
                    if '[[' in v or ']]' in v:
                        v=v.split('|')[-1].replace('[[','').replace(']]','').strip()
                    if v in ('{{','}}') or not v: continue
                    vk=v.replace('\u0301','') if target=='ru' else v
                    if v and vk not in seen: tr.append(v);seen.add(vk)
                defs=list(dict.fromkeys(plain(''.join(x.itertext())) for x in sense.iter(N+'def'))) or ['']
                # One source translation-group can contain several distinct attached glosses.
                for gloss in defs:
                    # A few upstream translation tokens are malformed markup, not words.
                    if not (tr or gloss): unavailable+=1; continue
                    # Do not present wiki maintenance discussions as dictionary definitions.
                    if re.match(r'^\(Should we move, merge or split',gloss): gloss=''
                    rec=[head, '; '.join(tr), gloss,pos,'',pron]
                    if rec not in data[k]: data[k].append(rec)
            el.clear()
    assert count==n
    # Within real source senses only: current readings precede explicitly archaic/obsolete readings.
    for senses in data.values():
        senses.sort(key=lambda s: bool(re.search(r'^\([^)]*\b(?:archaic|obsolete)\b',s[2],re.I)))
    meta=dict(id=f'freedict-{lang}-{target}',
        title={'en':'Английский → русский','ru':'Русский → английский'}[lang],
        description='Переводы из Викисловаря по значениям слова.' if lang=='en' else 'Русские слова, выражения и их английские переводы.',
        language=lang,target=target,source='FreeDict / WikDict',license='CC BY-SA 3.0',version=VERSION,
        sourceUrl='https://freedict.org/downloads/',licenseUrl='https://creativecommons.org/licenses/by-sa/3.0/',sourceEntries=n)
    notice=f"""FreeDict + WikDict · {pair} · 2025.11.23
Maintainer and publisher: Karl Bartel. Base dictionary text: Wiktionary contributors, via the DBnary project, adapted by WikDict and distributed by FreeDict.
https://www.wiktionary.org/ | https://kaiko.getalp.org/about-dbnary/ | https://www.wikdict.com/ | https://freedict.org/
Original editable TEI: {source_url}
Official checksums: https://freedict.org/freedict-database.json
Source archive SHA-512: {expected}
Copyright: the respective Wiktionary and dictionary contributors. Source license as identified by its own TEI header: Creative Commons Attribution-ShareAlike 3.0 Unported.
https://creativecommons.org/licenses/by-sa/3.0/ | https://creativecommons.org/licenses/by-sa/3.0/legalcode

This Folio adaptation, including all part-*.json files in this directory, is distributed under the same CC BY-SA 3.0 Unported license. No endorsement is implied. The accompanying LICENSE.txt is verbatim from the source package.
Changes: converted the selected TEI dictionary to normalized UTF-8 JSON key/sense groups; preserved source spelling, sense-specific translations, glosses and available pronunciations; expanded POS labels; unwrapped Wiktionary text links; collapsed duplicate variants; moved explicitly archaic/obsolete senses after current senses; added normalized lookup indexing and immutable shards. Number of source articles: {n:,}. Number of distinct case-normalized lookup headwords: {len(data):,}. The original is not a token-by-token or context-aware machine translator. No OCR, AI translation or private texts are used to build this pack.
"""
    return savepack(out,meta,data,notice,lic)

def wordnet(path,out):
    check(path,'sha256',WN_HASH)
    ranked=collections.defaultdict(list);header=''
    with tarfile.open(path,'r:gz') as t:
        aliases=[]
        for fst,ps in [('adj','adjective'),('adv','adverb'),('noun','noun'),('verb','verb')]:
            for line in t.extractfile('dict/'+fst+'.exc'):
                token,*lemmas=line.decode().split()
                for lemma in lemmas: aliases.append((token.replace('_',' '),lemma.replace('_',' '),ps))
        # Use the publisher's sense ranking & semantic concordance counts, not alphabetic synset order.
        index={}
        for l in t.extractfile('dict/index.sense'):
            sk, offset, num, count=l.decode().split()
            word, extra=sk.rsplit('%',1)
            pos={'1':'noun','2':'verb','3':'adjective','4':'adverb','5':'adjective'}[extra[0]]
            index[(word.lower(),pos,offset)]=(int(num),int(count))
        raw_count, no_rank = 0,0
        for group,pos in [('noun','noun'),('verb','verb'),('adj','adjective'),('adv','adverb')]:
            for bb in t.extractfile('dict/data.'+group):
                line=bb.decode().rstrip()
                if not line:continue
                if line[0]==' ':
                    if group=='noun': header+=re.sub(r'^\s*\d+\s?','',line)+'\n'
                    continue
                fields,gloss=line.split(' | ',1); words=fields.split()
                offset=words[0]; n=int(words[3],16)
                terms=words[4:4+n*2:2]
                # Only split the example suffix if its boundary indicates a quoted usage.
                d,mark,ex=gloss.partition('; "')
                if mark: ex='"'+ex
                for tok in terms:
                    # Adjective positional markers belong to WordNet syntax, not the lemma.
                    term=re.sub(r'\((?:p|a|ip)\)$','',tok)
                    rank=index.get((term.lower(),pos,offset),(1000,0))
                    if rank==(1000,0):no_rank+=1
                    head=term.replace('_',' ')
                    key=normalized(head,'en')
                    raw_count+=1
                    s=[head,'',d,pos,ex]
                    ranked[key].append(((-rank[1],rank[0],pos,offset),s))
        assert no_rank==0,(raw_count,no_rank)
    data={}
    for k,vals in ranked.items():
        data[k]=[list(x) for x in dict.fromkeys(tuple(s) for _,s in sorted(vals))]
    assert 'WordNet 3.1 Copyright 2011' in header and len(data)>140_000
    # Index attested forms only to matching lexical category; skip identities and references not in this release.
    heads=dict(data); links=0
    for token,lemma,pos in aliases:
        key=normalized(token,'en');base=normalized(lemma,'en')
        if key==base or base not in heads:continue
        vals=[s for s in heads[base] if s[3]==pos and normalized(s[0],'en')==base]
        if not vals:continue
        cell=data.setdefault(key,[])
        for v in vals:
            if v not in cell:cell.append(v.copy())
        links+=1
    meta=dict(id='wordnet-en-en',title='Толковый английский',description='Английские определения, части речи и примеры из WordNet 3.1.',
        language='en',target='en',source='WordNet 3.1',license='WordNet 3.1 License',version='3.1',
        sourceUrl='https://wordnet.princeton.edu/',licenseUrl='https://wordnet.princeton.edu/license-and-commercial-use')
    notice=f"""WordNet Release 3.1 · English definitions, examples and parts of speech.
WordNet 3.1 Copyright 2011 by Princeton University. All rights reserved.
https://wordnet.princeton.edu/ | https://wordnet.princeton.edu/license-and-commercial-use
Original database distribution: https://wordnetcode.princeton.edu/wn3.1.dict.tar.gz
Source archive SHA-256: {WN_HASH}

Modifications: converted the four WordNet lexical data tables (noun, verb, adjective, adverb) into offline JSON shards; used index.sense ranking and semantic concordance tag counts to sort actual senses; joined synonymous spelling variants only at normalized lookup keys. Preserved individual glosses and available textual usage examples. Indexed attested part-of-speech-specific exception-table forms (e.g. went → go and geese → goose) when they point to a lemma and matching part of speech in this release. Omitted synset graph relationships, frames and lexicographer metadata. This is not a full grammar or a bilingual translator. No endorsement is implied.

The text below from the 3.1 database headers applies to the WordNet data and its modifications.
\n"""+header
    lic=header.encode()
    return savepack(out,meta,data,notice,lic)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ['en-ru','ru-en','wordnet']:p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[2]/'dist/packs');a=p.parse_args()
    catalog=[freedict(a.en_ru,'eng-rus',a.out),wordnet(a.wordnet,a.out),freedict(a.ru_en,'rus-eng',a.out)]
    (a.out/'catalog.js').write_text('// Generated by tools/dictionaries/build.py; metadata only, no dictionary downloads on startup.\nexport const recommendedPacks = '+json.dumps(catalog,ensure_ascii=False,indent=2)+';\n')
if __name__=='__main__':main()

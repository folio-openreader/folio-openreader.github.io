Hindi dictionary source for the Folio adaptation
The complete original release, license and complete conversion scripts are included.
Requires only Python 3 standard library. To reproduce the Hindi pack:
  python3 build-extra.py --hi eng-hin.src.tar.xz --out rebuilt-packs
To edit, change the TEI in your own working copy and update the pinned checksum deliberately.
For changes to the data, keep the original credits and publish your changes under GPL-2.0-or-later.
